/*
 * Title:        Optimizing task offloading using the Gray wolf algorithm
 *  
 * Description:  using CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation
 *               of Clouds to implement a meta-heuristic algorithm (GWO) for task scheduling cost &
 *               makesapan optimization
 *
 * Copyright (c) 2024, USTHB, Algeria
 */


package org.cloudbus.cloudsim.examples;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.Vector;

//import org.cloudbus.cloudsim.Chromosomes;
import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerSpaceShared;
import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.DatacenterBrokerGWO;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
//import org.cloudbus.cloudsim.Gene;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicySimple;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.power.PowerHost;
import org.cloudbus.cloudsim.power.PowerVm;
import org.cloudbus.cloudsim.power.PowerVmAllocationPolicySimple;
import org.cloudbus.cloudsim.power.models.PowerModelLinear;
import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerIbmX3550XeonX5670;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;


public class OffloadingSimulation {

	/** la liste des taches */
	private static List<Cloudlet> cloudletList;

	/** la liste des machines */
	private static List<PowerVm> vmlist;
	
	/** PowerVM est La classe d'une VM qui stocke l'historique de l'utilisation des ressources */
	private static List<PowerVm> createVM(int userId, int vms) {

		//creation de la liste des VMs
		LinkedList<PowerVm> list = new LinkedList<PowerVm>();

		//configuration des VMs
		long size = 10000; 
		int ram = 512; 
		int mips = 1000; //puissance de calcul
		long bw = 10; //bande passante
		int pesNumber = 1; //nombre de coeurs (processeurs)
		String vmm = "Xen"; //virtual machine monitor

		//creation des VMs
		PowerVm[] vm = new PowerVm[vms];

		Random rmips=new Random(100);//pour varier la bande passante et la puissance de calcul des VMs
		for(int i=0;i<vms;i++){
			mips=rmips.nextInt(900);
			bw=10+rmips.nextInt(50);
			vm[i] = new PowerVm(i, userId, mips, pesNumber, ram, bw, size, 0, vmm, new CloudletSchedulerSpaceShared(), bw);

			list.add(vm[i]);
		}
		

		return list;
	}


	private static List<Cloudlet> createCloudlet(int userId, int cloudlets){
		// creation de liste des taches
		LinkedList<Cloudlet> list = new LinkedList<Cloudlet>();

		//configuration des taches 
		long length = 1000;
		long fileSize = 300;
		long outputSize = 300;
		int pesNumber = 1;
		UtilizationModel utilizationModel = new UtilizationModelFull(); //La classe UtilizationModelFull est un mod�le simple, selon lequel un Cloudlet utilise toujours toute la capacit� disponible de l'unit� centrale.
		
		Cloudlet[] cloudlet = new Cloudlet[cloudlets];

		for(int i=0;i<cloudlets;i++){
			Random random = new Random(12);
			int x = (int) (random.nextInt(100) * ((2000 - 1) + 1)) + 1; //pour varier al�atoirement la taille des taches
			cloudlet[i] = new Cloudlet(i, length+x, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
	
			cloudlet[i].setUserId(userId);
			list.add(cloudlet[i]);
		}

		return list;
	}


	////////////////////////// Methodes statiques ///////////////////////

	/**
	 * la m�thode main()
	 */
	public static void main(String[] args) {
		Log.printLine("d�marrage de la simulation");

		try {
			// premi�re �tape : initialiser le package Cloudsim
			int num_user = 1;   // nombre d'utilisateurs
			Calendar calendar = Calendar.getInstance();
			boolean trace_flag = false; 

			CloudSim.init(num_user, calendar, trace_flag);

			// Deuxi�me �tape : creation du datacenter
			@SuppressWarnings("unused")
			Datacenter datacenter0 = createDatacenter("Datacenter_0");

			//Troisi�me �tape : Cr�ation du courtier (broker) GWO
			DatacenterBrokerGWO broker = createBroker();
			int brokerId = broker.getId();

			//Quatri�me �tape : Cr�ation des VMs et des Cloudlets 
			vmlist = createVM(brokerId,10); //10 VMs
			cloudletList = createCloudlet(brokerId,20); // 20 taches
			
			//soumettre les VMs et les taches au broker
			broker.submitVmList(vmlist); 
			broker.submitCloudletList(cloudletList);

			//Derni�re �tape : d�marrer la simulation et afficher les r�sultats 
			CloudSim.startSimulation();
			
			List<Cloudlet> newList = broker.getCloudletReceivedList();
			
			CloudSim.stopSimulation();
			
			printCloudletList(newList);
			
			Log.printLine("OffloadingSimulation termin�");
		}
		catch (Exception e)
		{
			e.printStackTrace();
			Log.printLine("simulation int�ronpue a cause d'une �rreur");
		}
	}

	private static Datacenter createDatacenter(String name){

		// cr�ation de machines (hotes)
		List<PowerHost> hostList = new ArrayList<PowerHost>();

		// la machine contient un ou plusieurs processeur
		List<Pe> peList1 = new ArrayList<Pe>();

		int mips = 1000; //puissance d'un coeur
		//processeur quad core :
		peList1.add(new Pe(0, new PeProvisionerSimple(mips))); 
		peList1.add(new Pe(1, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(2, new PeProvisionerSimple(mips)));
		peList1.add(new Pe(3, new PeProvisionerSimple(mips))); 

		List<Pe> peList2 = new ArrayList<Pe>();
		//processeur Dual core :
		peList2.add(new Pe(0, new PeProvisionerSimple(mips)));
		peList2.add(new Pe(1, new PeProvisionerSimple(mips)));

		//configuration des hotes
		int hostId=0;
		int ram = 2048; 
		long storage = 1000000; //stockage en MB
		int bw = 10000;

		hostList.add(
    			new PowerHost(
    				hostId,
    				new RamProvisionerSimple(ram),
    				new BwProvisionerSimple(bw),
    				storage,
    				peList1,
    				new VmSchedulerTimeShared(peList1), new PowerModelSpecPowerIbmX3550XeonX5670()
    			)
    		); // premi�re machine

		hostId++;

		hostList.add(
    			new PowerHost(
    				hostId,
    				new RamProvisionerSimple(ram),
    				new BwProvisionerSimple(bw),
    				storage,
    				peList2,
    				new VmSchedulerTimeShared(peList2), new PowerModelSpecPowerIbmX3550XeonX5670()
    			)
    		); // Deuxi�me machine
		hostList.add(
    			new PowerHost(
    				hostId,
    				new RamProvisionerSimple(ram),
    				new BwProvisionerSimple(bw),
    				storage,
    				peList2,
    				new VmSchedulerTimeShared(peList2), new PowerModelSpecPowerIbmX3550XeonX5670()
    			)
    		); // Troixi�me machine



		// creation d'une instance de DatacenterCharacteristics 
		//repr�sente les propri�t�s d'une ressource telles que l'architecture de la ressource,
		//le syst�me d'exploitation (OS), la politique de gestion (temps ou espace partag�), 
		//le co�t et le fuseau horaire dans lequel la ressource est situ�e, ainsi que la tarification de la ressource.
		
		String arch = "x86";      
		String os = "Linux";          
		String vmm = "Xen";
		double time_zone = 10.0;        
		double cost = 3.0;              // cout de calcul
		double costPerMem = 0.05;		// cout de la RAM
		double costPerStorage = 0.1;	// cout de stockage
		double costPerBw = 0.1;			// cout de la bande passante
		LinkedList<Storage> storageList = new LinkedList<Storage>();

		DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
                arch, os, vmm, hostList, time_zone, cost, costPerMem, costPerStorage, costPerBw);


		//finalement, la cr�ation du Datacenter
		Datacenter datacenter = null;
		try {
			datacenter = new Datacenter(name, characteristics, new PowerVmAllocationPolicySimple(hostList), storageList, 0);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return datacenter;
	}

	//notre brocker
	private static DatacenterBrokerGWO createBroker(){

		DatacenterBrokerGWO broker = null;
		try {
			broker = new DatacenterBrokerGWO("GWO_Broker");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return broker;
	}

	//fonction pour afficher le d�roulement et les r�sultats de la simulation
	private static void printCloudletList(List<Cloudlet> list) {
		int size = list.size();
		Cloudlet cloudlet;

		String indent = "    ";
		Log.printLine();
		Log.printLine("========== OUTPUT ==========");
		Log.printLine("Cloudlet ID" + indent + "STATUS" + indent +
				"Data center ID" + indent + "VM ID" + indent + indent + "Time" + indent + "Start Time" + indent + "Finish Time");

		DecimalFormat dft = new DecimalFormat("###.##");
		for (int i = 0; i < size; i++) {
			cloudlet = list.get(i);
			Log.print(indent + cloudlet.getCloudletId() + indent + indent);

			if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS){
				Log.print("SUCCESS");

				Log.printLine( indent + indent + cloudlet.getResourceId() + indent + indent + indent + cloudlet.getVmId() +
						indent + indent + indent + dft.format(cloudlet.getActualCPUTime()) +
						indent + indent + dft.format(cloudlet.getExecStartTime())+ indent + indent + indent + dft.format(cloudlet.getFinishTime()));
			}
		}

	}
}
